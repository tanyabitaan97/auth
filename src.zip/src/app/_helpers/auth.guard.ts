import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthenticationService } from '../_services/authentication.service';//import custom service

//Custom service class that manages the ROute Guard
@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {
    constructor( private router: Router, private authenticationService: AuthenticationService ) {} //DI

    //override system defined method
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {      
        const currentUser = this.authenticationService.currentUserValue; //get current user from auth service

        if (currentUser) {// authorised so return true
            return true;
        }
        
        // not logged in so redirect to login page with the return url
        this.router.navigate(['/login'], { queryParams: { returnUrl: state.url }});
        return false;
    }
}