export class Role {
    user:any;
    admin:any;
}