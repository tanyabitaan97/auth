//sets custom configuration i.e url and port to host the fake REST API

export const environment = {
    production: false,
    apiUrl: 'http://localhost:4000'
};